#!/bin/bash
# Setup EndeavourOS repo for ISO build (airootfs)

set -e

echo "[+] Importing EndeavourOS key..."
pacman-key --init
pacman-key --recv-key 3B94A80E50D5C2B4
pacman-key --lsign-key 3B94A80E50D5C2B4

echo "[+] Adding EndeavourOS repo to pacman.conf..."
cat >> /etc/pacman.conf << 'EOF'

[endeavouros]
SigLevel = PackageRequired
Include = /etc/pacman.d/endeavouros-mirrorlist
EOF

echo "[+] Fetching EndeavourOS mirrorlist..."
curl -sSL -o /etc/pacman.d/endeavouros-mirrorlist https://raw.githubusercontent.com/endeavouros-team/mirrors/main/endeavouros-mirrorlist

echo "[+] Installing EndeavourOS keyring..."
pacman -Sy --noconfirm endeavouros-keyring
