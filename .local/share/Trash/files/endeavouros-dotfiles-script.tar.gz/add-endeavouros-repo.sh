#!/bin/bash
# Add EndeavourOS Repo for Installed System

set -e

# Import and sign EndeavourOS key
pacman-key --recv-key 3B94A80E50D5C2B4
pacman-key --lsign-key 3B94A80E50D5C2B4

# Add repo to pacman.conf if not present
if ! grep -q "\[endeavouros\]" /etc/pacman.conf; then
  echo -e "\n[endeavouros]\nSigLevel = PackageRequired\nInclude = /etc/pacman.d/endeavouros-mirrorlist" >> /etc/pacman.conf
fi

# Download mirrorlist
curl -sSL -o /etc/pacman.d/endeavouros-mirrorlist https://raw.githubusercontent.com/endeavouros-team/mirrors/main/endeavouros-mirrorlist

# Sync and install EndeavourOS keyring
pacman -Sy --noconfirm endeavouros-keyring
